# Internship Portal — Setup & Deployment Guide

Stack: **Python (FastAPI) backend · HTML/CSS/JS frontend · Supabase (Postgres + Auth + Storage)**.
No dummy data anywhere — every table starts empty and every screen reads real rows.

---

## 0. Supabase vs Firebase — direct answer

**Use Supabase only. Don't add Firebase.** Reasons:

- Supabase's free Postgres tier gives you 500MB database + 1GB file storage + 5GB bandwidth/month, which comfortably covers a portal under ~100 students with lesson videos stored as MP4 links.
- Splitting data across two databases (Supabase for structured data, Firebase for "overflow" storage) doubles your auth, security-rules, and sync complexity for a scale you're not at yet. It's not "more storage," it's two systems to keep consistent.
- If you ever *do* outgrow Supabase's free tier, the fix is upgrading Supabase's paid plan (still cheaper and simpler than running two backends), or moving large video files to a dedicated free video CDN (Cloudflare R2 / Bunny free tier) while keeping everything else in Supabase.

So: **Supabase for everything** (auth, database, and the two storage buckets for avatar photos + rendered videos). This is already wired up in the code below.

---

## 1. What's included

```
internship-portal/
├── database/schema.sql       # run this in Supabase SQL editor — creates all tables + RLS, no seed data
├── backend/                  # FastAPI app
│   └── app/
│       ├── main.py           # app entrypoint, CORS, routers
│       ├── config.py         # env var loading
│       ├── db.py             # Supabase service-role client
│       ├── auth.py           # verifies Supabase JWTs from the frontend
│       ├── courses.py        # courses + lessons CRUD, lesson approval
│       ├── jobs.py           # video render queue (what Colab talks to)
│       ├── submissions.py    # student submissions + real AI grading (Gemini/Groq)
│       ├── mentor.py         # AI mentor chat (Groq)
│       └── ai_providers.py   # Gemini/Groq API wrappers with fallback
├── frontend/                 # plain HTML/CSS/JS, no build step
│   ├── index.html            # login/signup (Supabase Auth)
│   ├── dashboard.html        # student: courses, lessons, submissions, mentor chat
│   ├── admin.html            # admin: create courses/lessons, approve for render, live job queue, review submissions
│   ├── css/style.css
│   └── js/{config,supabaseClient,api}.js
└── colab/render_worker.py    # paste into your Colab/Kaggle notebook — SadTalker batch worker
```

**Covered end-to-end and real (not mocked):** auth + roles, course/lesson creation, the approve → video-job-queue → Colab-render → video-ready pipeline, AI-graded submissions, AI mentor chat with persisted history, and a live admin render-queue dashboard.

**Not yet built** (from your original plan — say the word and I'll build any of these next): progress-tracking dashboards/charts, leaderboards, plagiarism checks, notifications, audit logging, and enrollment-limits/admin user management UI. The schema already has an `enrollments.progress` column ready for progress tracking.

---

## 2. Supabase setup (10 minutes)

1. Create a project at supabase.com (free tier).
2. **SQL Editor** → paste all of `database/schema.sql` → Run.
3. **Storage** → create two buckets: `avatars` and `lesson-videos`, both set to **Public**.
4. **Project Settings → API** → copy:
   - `Project URL` → `SUPABASE_URL`
   - `anon public` key → `SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (keep secret — backend only)
5. **Project Settings → API → JWT Settings** → copy the `JWT Secret` → `SUPABASE_JWT_SECRET`
6. **Make your first admin:** sign up normally through `index.html` once deployed, then in the SQL Editor run:
   ```sql
   update profiles set role = 'admin' where id = 'paste-your-user-uuid-here';
   -- find your uuid in Authentication -> Users
   ```

---

## 3. AI provider keys (both free)

- Gemini: https://aistudio.google.com/app/apikey → `GEMINI_API_KEY`
- Groq: https://console.groq.com/keys → `GROQ_API_KEY`

---

## 4. Run the backend locally first

```bash
cd backend
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in every value from steps 2-3 above
uvicorn app.main:app --reload --port 8000
```
Check `http://localhost:8000/health` → `{"status":"ok"}`.

---

## 5. Deploy the backend live

Any Python host works; **Render.com free tier** is the simplest:
1. Push this repo to GitHub.
2. Render → New → Web Service → point at your repo, root directory `backend`.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. Add all the `.env` variables in Render's Environment tab.
6. Once deployed, copy the live URL (e.g. `https://your-app.onrender.com`).

(Railway, Fly.io, or a VPS with gunicorn/nginx work identically — same env vars, same start command shape.)

---

## 6. Deploy the frontend live

No build step — it's static HTML/CSS/JS. **Netlify, Vercel, GitHub Pages, or Cloudflare Pages** (all free) — just point them at the `frontend/` folder.

Before deploying, edit `frontend/js/config.js` with your real live values:
```js
const APP_CONFIG = {
  SUPABASE_URL: "https://your-project.supabase.co",
  SUPABASE_ANON_KEY: "your-real-anon-key",
  API_BASE_URL: "https://your-backend.onrender.com",
};
```

Then back in the backend `.env`, set `FRONTEND_ORIGIN` to your live frontend URL (for CORS) and redeploy the backend.

---

## 7. Set up the Colab/Kaggle render worker

1. Open a new Colab (or Kaggle) notebook with a GPU runtime.
2. Upload your one presenter photo, name it `presenter.jpg`.
3. Copy `colab/render_worker.py` into notebook cells, splitting where marked `# --- CELL n ---`.
4. Fill in Cell 2's config: your live `API_BASE_URL`, the same `WORKER_API_KEY` from your backend `.env`, your `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`.
5. Run all cells. Cell 5 (`run_batch()`) drains the whole queue — every lesson an admin approved since the last run gets rendered, uploaded, and marked ready automatically.
6. Repeat weekly (or whenever you've approved a new batch of lessons) — open the notebook, run it, close it. That's the entire batch workflow.

---

## 8. Realistic order to build next

1. Deploy steps 2–7 above and confirm one full lesson goes draft → approved → queued → rendered → visible to a student.
2. Progress tracking (you already have `enrollments.progress` — needs a small backend endpoint + a progress bar on the dashboard).
3. Leaderboard (a `GET /leaderboard` endpoint aggregating `submissions.ai_score` by student).
4. Notifications + audit log (both are straightforward new tables + a couple of endpoints, no new architecture needed).

Happy to build any of those next — just tell me which one.
